package cn.seisys.lostfound;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.Map;

import cn.seisys.lostfound.db.LostFoundDao;
import cn.seisys.lostfound.db.LostFoundEntity;
import cn.seisys.lostfound.utils.StatusBarUtil;

public class AddActivity extends AppCompatActivity implements View.OnClickListener  {

    private FragmentManager fragmentManager;
    private Fragment[] fragments;
    private Integer tabIndex=0;

    private LostFoundDao lostFoundDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
 //      View view_need_offset = findViewById(R.id.view_need_offset);
 //      StatusBarUtil.setTranslucentForImageView(this, 0, view_need_offset);

        findViewById(R.id.imgBack).setOnClickListener(this);
        findViewById(R.id.btnSave).setOnClickListener(this);

        tabIndex = 0;
        fragments = new Fragment[]{new LostFragment(), new LostFragment()};
        fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.add(R.id.fl_container_layout, fragments[tabIndex]).show(fragments[tabIndex]).commit();

        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.radioBtnLost){
                    setTabSelect(0);
                }else if(checkedId == R.id.radioBtnFound){
                    setTabSelect(1);
                }
            }
        });

        lostFoundDao = new LostFoundDao(this);
    }

    @Override
    public void onClick(View v) {
        int vId = v.getId();
        if(R.id.imgBack == vId){
            finish();
        }else  if(R.id.btnSave == vId){
            Map<String, String> dataFromFragment = ((LostFoundDataProvider) fragments[tabIndex]).getFragmentData();
            String name = dataFromFragment.get("name");
            if(TextUtils.isEmpty(name)){
                Toast.makeText(this, "name is empty!", Toast.LENGTH_LONG).show();
                return;
            }
            String phone = dataFromFragment.get("phone");
            if(TextUtils.isEmpty(phone)){
                Toast.makeText(this, "phone is empty!", Toast.LENGTH_LONG).show();
                return;
            }
            String desc = dataFromFragment.get("desc");
            if(TextUtils.isEmpty(desc)){
                Toast.makeText(this, "description is empty!", Toast.LENGTH_LONG).show();
                return;
            }
            String date = dataFromFragment.get("date");
            if(TextUtils.isEmpty(date)){
                Toast.makeText(this, "date is empty!", Toast.LENGTH_LONG).show();
                return;
            }
            String location = dataFromFragment.get("location");
            if(TextUtils.isEmpty(location)){
                Toast.makeText(this, "location is empty!", Toast.LENGTH_LONG).show();
                return;
            }

            LostFoundEntity lostFoundEntity=new LostFoundEntity(name, phone, desc, date, location, tabIndex==0?"1":"0");
            lostFoundDao.addLostFound(lostFoundEntity);
            finish();
        }
    }

    private void setTabSelect(int i){
        if (tabIndex == i) {
            return;
        }

        Fragment toFragment = fragments[i];
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        if(toFragment.isAdded()){
            transaction.hide(fragments[tabIndex]).show(toFragment).commit();
        }else{
            transaction.hide(fragments[tabIndex]).add(R.id.fl_container_layout, toFragment).show(toFragment).commit();
        }
        tabIndex = i;
    }
}