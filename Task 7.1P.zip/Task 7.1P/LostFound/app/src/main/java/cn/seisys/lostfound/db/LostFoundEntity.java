package cn.seisys.lostfound.db;

public class LostFoundEntity {
    public String name;
    public String phone;
    public String desc;
    public String date;
    public String location;
    public String lostType;

    public LostFoundEntity(String name, String phone, String desc, String date, String location, String lostType){
        this.name =name;
        this.phone=phone;
        this.desc =desc;
        this.date=date;
        this.location=location;
        this.lostType=lostType;
    }


}
