package cn.seisys.lostfound;

import java.util.Map;

public interface LostFoundDataProvider {
    Map<String, String> getFragmentData();
}
