package cn.seisys.lostfound.utils;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.security.MessageDigest;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils {

	private static String nums[] = {"零", "一", "二", "三", "四", "五", "六", "七", "八", "九"};
	private static String pos_units[] = {"", "十", "百", "千"};
	private static String weight_units[] = {"", "万", "亿"};

	public static int dip2px(Context context, float dipValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		int n = (int) (dipValue * scale + 0.5f);
		return (int) (dipValue * scale + 0.5f);
	}

	public static int px2dip(Context context, float pxValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (pxValue / scale + 0.5f);
	}


	public static String getImagePath(Context context, Uri uri, String selection){
		String path = null;
		//通过Uri和selection来获取真实的图片路径
		Cursor cursor = context.getContentResolver().query(uri,null, selection,null,null);
		if (cursor != null){
			if (cursor.moveToFirst()){
				path = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
			}
			cursor.close();
		}
		return path;
	}

	public static String getRealFilePath(Context context, Uri uri){
		if ( null == uri ) return null;
		final String scheme = uri.getScheme();
		String data = null;
		if ( scheme == null )
			data = uri.getPath();
		else if ( ContentResolver.SCHEME_FILE.equals( scheme ) ) {
			data = uri.getPath();
		} else if ( ContentResolver.SCHEME_CONTENT.equals( scheme ) ) {
			Cursor cursor = context.getContentResolver().query( uri, new String[] { MediaStore.Images.ImageColumns.DATA }, null, null, null );
			if ( null != cursor ) {
				if ( cursor.moveToFirst() ) {
					int index = cursor.getColumnIndex( MediaStore.Images.ImageColumns.DATA );
					if ( index > -1 ) {
						data = cursor.getString( index );
					}
				}
				cursor.close();
			}
		}
		return data;
	}

	public static String convertFilePath(Context context, String filePath){
		String uriString;
		File file = new File(filePath);
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N){
			uriString = Uri.fromFile(file).toString();
		}else{
			Uri contentUri = FileProvider.getUriForFile(context, context.getPackageName()+".fileProvider", file);
			uriString = contentUri.toString();
		}
		return uriString;
	}

	/**
	 * 获取状态栏的高度
	 */
	public static int getStatusBarHeight(Context context) {
		int result = 0;
		int resourceId = context.getResources()
				.getIdentifier("status_bar_height", "dimen", "android");
		if (resourceId > 0) {
			result = context.getResources()
					.getDimensionPixelSize(resourceId);
		}
		return result;
	}

	/**
	 * 取导航栏高度
	 */
	public static int getNavigationBarHeight(Context context) {
		int result = 0;
		int resourceId = context.getResources().getIdentifier("navigation_bar_height", "dimen", "android");
		if (resourceId > 0) {
			result = context.getResources().getDimensionPixelSize(resourceId);
		}
		return result;
	}

	/**
	 * 隐藏软键盘
	 */
	public static void hideSoftInput(Activity activity) {
		InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
		if(inputMethodManager == null){
			return;
		}

		View view = activity.getCurrentFocus();
		if(view == null) {
			return;
		}

		inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
	}

	/**
	 * 显示软键盘
	 */
	public static void showSoftInput(View view) {
		if (view == null) return;
		if (view instanceof EditText){
			view.setFocusable(true);
			view.setFocusableInTouchMode(true);
			view.requestFocus();
		}

		InputMethodManager inputMethodManager = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
		if (inputMethodManager != null) {
			inputMethodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
		}
	}

	/**
	 * 显示软键盘
	 */
	public static void showInputMethod(Context context) {
		InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
	}

	//(CJK统一汉字的编码区间：0x4e00–0x9fbb)
	public static boolean isChinese(String s) {
		if (s.matches("^[\\u4e00-\\u9fa5]+$")){
			return true;
		}else {
			return false;
		}
	}

	public static boolean checkTextValid(String s){
		boolean valid = true;
		if(s==null || "null".equals(s) || s.isEmpty()){
			valid = false;
		}
		return valid;
	}

	/**
	 * 多少时间后显示软键盘
	 */
	public static void showInputMethod(final View view, long delayMillis) {
		if (view != null)
		// 显示输入法
		{
			view.postDelayed(new Runnable() {

				@Override
				public void run() {
					showSoftInput(view);
				}
			}, delayMillis);
		}
	}

	public static void toastMessage(Context context, String msg) {
		Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
	}

	public static boolean isNetworkAvailable(Context context){
		ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivity != null) {
			NetworkInfo info = connectivity.getActiveNetworkInfo();
			if (info!=null && info.isConnected()) {
				// 当前网络是连接的
				if (info.getState() == NetworkInfo.State.CONNECTED) {
					// 当前所连接的网络可用
					return true;
				}
			}
		}
		return false;
	}

	public static int compareAppVersion(String version1, String version2) {
		if (version1 == null || version2 == null) {
			throw new RuntimeException("版本号不能为空");
		}
		// 注意此处为正则匹配，不能用.
		String[] versionArray1 = version1.split("\\.");
		String[] versionArray2 = version2.split("\\.");
		int idx = 0;
		// 取数组最小长度值
		int minLength = Math.min(versionArray1.length, versionArray2.length);
		int diff = 0;
		// 先比较长度，再比较字符
		while (idx < minLength
				&& (diff = versionArray1[idx].length() - versionArray2[idx].length()) == 0
				&& (diff = versionArray1[idx].compareTo(versionArray2[idx])) == 0) {
			++idx;
		}
		// 如果已经分出大小，则直接返回，如果未分出大小，则再比较位数，有子版本的为大
		diff = (diff != 0) ? diff : versionArray1.length - versionArray2.length;
		return diff;
	}

	public static String getSerialNumber() {

		String serial = null;

		try {

			Class<?> c = Class.forName("android.os.SystemProperties");

			Method get = c.getMethod("get", String.class);

			serial = (String) get.invoke(c, "ro.serialno");

		} catch (Exception e) {

			e.printStackTrace();

		}

		return serial;

	}

	// md5加密
	public static String getMD5Code(String message) {
		String md5Str = "";
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] md5Bytes = md.digest(message.getBytes());
			md5Str = bytes2Hex(md5Bytes);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return md5Str;
	}

	public static String bytes2Hex(byte[] bytes) {
		StringBuffer result = new StringBuffer();
		int temp;
		try {
			for (int i = 0; i < bytes.length; i++) {
				temp = bytes[i];
				if (temp < 0) {
					temp += 256;
				}
				if (temp < 16) {
					result.append("0");
				}
				result.append(Integer.toHexString(temp));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static void copyToClipboard(Context context, String szContent) {
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
			android.text.ClipboardManager clipboard = (android.text.ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
			clipboard.setText(szContent);
		} else {
			ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
			ClipData clip = ClipData.newPlainText("Copied Text", szContent);
			clipboard.setPrimaryClip(clip);
		}
	}

	public static boolean isEmailAddress(String emailAddress){
		String emailAddressRegex = "^([a-z0-9A-Z]+[-_|\\.]?)+[a-z0-9A-Z]@([a-z0-9]+(-[a-z0-9A-Z]+)?\\.)+[a-z]{2,}$";
		Pattern pattern = Pattern.compile(emailAddressRegex);
		Matcher matcher = pattern.matcher(emailAddress);
		return matcher.matches();
	}

	public static boolean isMobileNO(String mobiles) {
		/*
		 * 移动：134、135、136、137、138、139、150、151、157(TD)、158、159、187、188
		 * 联通：130、131、132、152、155、156、185、186 电信：133、153、180、189、（1349卫通）
		 * 总结起来就是第一位必定为1，第二位必定为3或5或8，其他位置的可以为0-9
		 */
		String telRegex = "[1][3456789]\\d{9}";// "[1]"代表第1位为数字1，"[358]"代表第二位可以为3、5、8中的一个，"\\d{9}"代表后面是可以是0～9的数字，有9位。
		return mobiles.matches(telRegex);
	}
	
	/**
     * 获取count位随机数字
     * 
     * @return
     */
    public static String getrRandomCode(int count) {
        // 创建一个随机数生成器类。
        Random random = new Random();
        StringBuffer randomCode = new StringBuffer();
        for (int i = 0; i < count; i++) {
            // 得到随机产生的验证码数字。
            String strRand = String.valueOf(random.nextInt(10));
            randomCode.append(strRand);
        }
        return randomCode.toString();
        
    }
    public static String pas16To10(String str)
    {
    	return Integer.parseInt(str,16) +"";
    }


	public static String numberToChinese(int num) {
		if (num == 0) {
			return "零";
		}

		int weigth = 0;//节权位
		String chinese = "";
		String chinese_section = "";
		boolean setZero = false;//下一小节是否需要零，第一次没有上一小节所以为false
		while (num > 0) {
			int section = num % 10000;//得到最后面的小节
			if (setZero) {//判断上一小节的千位是否为零，是就设置零
				chinese = nums[0] + chinese;
			}
			chinese_section = sectionTrans(section);
			if (section != 0) {//判断是都加节权位
				chinese_section = chinese_section + weight_units[weigth];
			}
			chinese = chinese_section + chinese;
			chinese_section = "";

			setZero = (section < 1000) && (section > 0);
			num = num / 10000;
			weigth++;
		}
		if ((chinese.length() == 2 || (chinese.length() == 3)) && chinese.contains("一十")) {
			chinese = chinese.substring(1, chinese.length());
		}
		if (chinese.indexOf("一十") == 0) {
			chinese = chinese.replaceFirst("一十", "十");
		}

		return chinese;
	}

	public static String sectionTrans(int section) {
		StringBuilder section_chinese = new StringBuilder();
		int pos = 0;//小节内部权位的计数器
		boolean zero = true;//小节内部的置零判断，每一个小节只能有一个零。
		while (section > 0) {
			int v = section % 10;//得到最后一个数
			if (v == 0) {
				if (!zero) {
					zero = true;//需要补零的操作，确保对连续多个零只是输出一个
					section_chinese.insert(0, nums[0]);
				}
			} else {
				zero = false;//有非零数字就把置零打开
				section_chinese.insert(0, pos_units[pos]);
				section_chinese.insert(0, nums[v]);
			}
			pos++;
			section = section / 10;
		}

		return section_chinese.toString();
	}

    public   static String pasFenToYuan(String str)
    {
    	int amount = Integer.parseInt(str);
    	double n = (double)amount/100;
    	return n + "";
    }
    
    public static File genlogfile(String content, String filename) {
		String imageDir = Environment.getExternalStorageDirectory().getPath()
				+ "/hzw/";
		File file = new File(imageDir);
		if (!file.exists()) {
			file.mkdirs();
		}
		FileOutputStream fos = null;
		// 创建文件
		File f = new File(imageDir + filename);
		try {
			if (!f.exists()) {
				f.createNewFile();
			}
			byte bytes[] = new byte[512];
			bytes = content.getBytes(); // 新加的
			int b = content.length(); // 改
			fos = new FileOutputStream(f);
			fos.write(bytes, 0, b);
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != fos)
				{
					fos.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return f;

	}
    
    public static File genAppendlogfile(String content, String filename) {
		String imageDir = Environment.getExternalStorageDirectory().getPath()
				+ "/hzw/";
		File file = new File(imageDir);
		if (!file.exists()) {
			file.mkdirs();
		}
		// 创建文件
		BufferedWriter output = null;
		File f = new File(imageDir + filename);
		try {
			if (!f.exists()) {
				f.createNewFile();
			}
			output = new BufferedWriter(new FileWriter(f,true));
            output.write(content+"\r\n");
            output.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != output)
				{
					output.close();
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return f;
	}

	public static String getVersionName(Context con) {
		PackageManager packageManager = con.getPackageManager();
		PackageInfo packInfo;
		try {
			packInfo = packageManager.getPackageInfo(con.getPackageName(), 0);
			String version = packInfo.versionName;
			return version;
		} catch (PackageManager.NameNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static Bitmap getLoacalBitmap(String url) {
		try {
			FileInputStream fis = new FileInputStream(url);
			return BitmapFactory.decodeStream(fis);  ///把流转化为Bitmap图片

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}
}
