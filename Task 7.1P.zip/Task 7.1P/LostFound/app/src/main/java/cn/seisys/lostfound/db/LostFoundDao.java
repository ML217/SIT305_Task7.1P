package cn.seisys.lostfound.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

public class LostFoundDao {

    private SQLiteDatabase sqLiteDb;
    private DBOpenHelper dbOpenHelper;

    public LostFoundDao(Context context){
        dbOpenHelper = new DBOpenHelper(context);
    }


    public void addLostFound(LostFoundEntity lostFoundEntity){
        sqLiteDb = dbOpenHelper.getReadableDatabase();

        ContentValues values = new ContentValues();
        values.put("fd_name", lostFoundEntity.name);
        values.put("fd_phone", lostFoundEntity.phone);
        values.put("fd_desc", lostFoundEntity.desc);
        values.put("fd_date", lostFoundEntity.date);
        values.put("fd_location", lostFoundEntity.location);
        values.put("fd_type", lostFoundEntity.lostType);
        sqLiteDb.insert("tb_lostfound", null, values);

        sqLiteDb.close();
    }

    public List<LostFoundEntity> queryLostFound(String keyword, List<LostFoundEntity> lostFoundList){
        Cursor cursor = null;
        lostFoundList.clear();
        sqLiteDb = dbOpenHelper.getReadableDatabase();
        if(TextUtils.isEmpty(keyword)){
            cursor = sqLiteDb.rawQuery("SELECT * FROM tb_lostfound", null);
        }else{
            String[] selectionArgs = new String[]{"%" + keyword + "%", "%" + keyword + "%"};
            cursor = sqLiteDb.rawQuery("SELECT * FROM tb_lostfound WHERE fd_name like ? or fd_desc like ?", selectionArgs);
        }

 //       List<LostFoundEntity> lostFoundList = new ArrayList<>();
        while (cursor!=null && cursor.moveToNext()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow("fd_name"));
            String phone = cursor.getString(cursor.getColumnIndexOrThrow("fd_phone"));
            String desc = cursor.getString(cursor.getColumnIndexOrThrow("fd_desc"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("fd_date"));
            String location = cursor.getString(cursor.getColumnIndexOrThrow("fd_location"));
            String lostType = cursor.getString(cursor.getColumnIndexOrThrow("fd_type"));
            lostFoundList.add(new LostFoundEntity(name, phone, desc, date, location, lostType));
        }
        cursor.close();
        sqLiteDb.close();

        return lostFoundList;
    }
}
