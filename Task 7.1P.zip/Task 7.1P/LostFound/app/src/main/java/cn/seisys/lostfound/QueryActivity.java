package cn.seisys.lostfound;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import cn.seisys.lostfound.db.LostFoundDao;
import cn.seisys.lostfound.db.LostFoundEntity;
import cn.seisys.lostfound.utils.StatusBarUtil;
import cn.seisys.lostfound.utils.Utils;

public class QueryActivity extends AppCompatActivity implements View.OnClickListener{

    protected Context context;

    private EditText editSearchText;
    private ImageView imgClear;

    private BaseAdapter adapter;

    private LostFoundDao lostFoundDao;

    List<LostFoundEntity> lostFoundEntityList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_query);

        context = this;
        lostFoundDao = new LostFoundDao(this);

        ListView listView = findViewById(R.id.listView);
        listView.setEmptyView(findViewById(R.id.ll_emptyview_layout));
        adapter = new LostFoundItemAdapter();
        listView.setAdapter(adapter);

        findViewById(R.id.imgBack).setOnClickListener(this);
        imgClear = findViewById(R.id.imgClear);
        imgClear.setOnClickListener(this);

        editSearchText = findViewById(R.id.editSearchText);
        editSearchText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(TextUtils.isEmpty(s.toString())){
                    imgClear.setVisibility(View.GONE);
                    lostFoundEntityList.clear();
                    adapter.notifyDataSetChanged();
                    Utils.showSoftInput(editSearchText);
                }else{
                    imgClear.setVisibility(View.VISIBLE);
                    queryLostFound(editSearchText.getText().toString().trim());
                }
            }
        });
        queryLostFound(null);
    }

    @Override
    public void onClick(View v) {
        int clickedViewId = v.getId();
        if(R.id.imgBack == clickedViewId){
            finish();
        }else if(clickedViewId == R.id.imgClear){
            editSearchText.setText("");
        }
    }

    public void queryLostFound(String keyword){
        lostFoundEntityList.clear();
        lostFoundDao.queryLostFound(keyword, lostFoundEntityList);
        adapter.notifyDataSetChanged();
    }


    public class LostFoundItemAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return lostFoundEntityList==null?0:lostFoundEntityList.size();
        }

        @Override
        public Object getItem(int position) {
            return lostFoundEntityList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            if(convertView == null){
                convertView = LayoutInflater.from(context).inflate(R.layout.item_lostfound, null);
                viewHolder = new ViewHolder();
                viewHolder.textName = convertView.findViewById(R.id.textName);
                viewHolder.textPhone = convertView.findViewById(R.id.textPhone);
                viewHolder.textDesc = convertView.findViewById(R.id.textDesc);
                viewHolder.textDate = convertView.findViewById(R.id.textDate);
                viewHolder.textLocation = convertView.findViewById(R.id.textLocation);
                viewHolder.textType = convertView.findViewById(R.id.textType);
                convertView.setTag(viewHolder);
            }else{
                viewHolder = (ViewHolder) convertView.getTag();
            }

            viewHolder.textName.setText(lostFoundEntityList.get(position).name);
            viewHolder.textPhone.setText(lostFoundEntityList.get(position).phone);
            viewHolder.textDesc.setText(lostFoundEntityList.get(position).desc);
            viewHolder.textDate.setText(lostFoundEntityList.get(position).date);
            viewHolder.textLocation.setText(lostFoundEntityList.get(position).location);
            if("1".equals(lostFoundEntityList.get(position).lostType)){
                viewHolder.textType.setTextColor(Color.parseColor("#8000FF"));
                viewHolder.textType.setText("lost");
            }else{
                viewHolder.textType.setTextColor(Color.parseColor("#0000FF"));
                viewHolder.textType.setText("found");
            }

            return convertView;
        }

        private class ViewHolder{
            public TextView textName, textPhone, textDesc, textDate, textLocation, textType;
        }
    }
}