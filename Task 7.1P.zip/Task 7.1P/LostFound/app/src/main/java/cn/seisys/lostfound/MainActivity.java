package cn.seisys.lostfound;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private int tabIndex = -1;


    private Button btnAdd, btnQuery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAdd = findViewById(R.id.btnAdd);
        btnQuery = findViewById(R.id.btnQuery);

        btnAdd.setOnClickListener(this);
        btnQuery.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if(R.id.btnAdd == id){
            Intent intent = new Intent(this, AddActivity.class);
            startActivity(intent);
        }else if(R.id.btnQuery == id){
            Intent intent = new Intent(this, QueryActivity.class);
            startActivity(intent);
        }
    }
}